jupackage com.example.firebaserealtimeapp;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.*;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    EditText editText1, editText2;
    Button btnSubmit, btnView;
    ListView listView;

    DatabaseReference database;
    ArrayList<String> entries;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText1 = findViewById(R.id.editText1);
        editText2 = findViewById(R.id.editText2);
        btnSubmit = findViewById(R.id.btnSubmit);
        btnView = findViewById(R.id.btnView);
        listView = findViewById(R.id.listView);

        database = FirebaseDatabase.getInstance(
                "https://community-app-ba02c-default-rtdb.firebaseio.com/"
        ).getReference("entries");

        entries = new ArrayList<>();

        adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                entries
        );

        listView.setAdapter(adapter);

        btnSubmit.setOnClickListener(v -> saveData());

        btnView.setOnClickListener(v -> loadData());
    }

    private void saveData() {

        String first = editText1.getText().toString().trim();
        String second = editText2.getText().toString().trim();

        if (first.isEmpty() || second.isEmpty()) {
            Toast.makeText(this, "Please fill in both fields",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        HashMap<String, String> record = new HashMap<>();
        record.put("first", first);
        record.put("second", second);

        database.push().setValue(record)
                .addOnSuccessListener(unused -> {
                    editText1.setText("");
                    editText2.setText("");
                    Toast.makeText(this, "Saved successfully!",
                            Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Save failed: " + e.getMessage(),
                                Toast.LENGTH_LONG).show()
                );
    }

    private void loadData() {

        database.addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {

                        entries.clear();

                        for (DataSnapshot child : snapshot.getChildren()) {

                            String first = child.child("first")
                                    .getValue(String.class);

                            String second = child.child("second")
                                    .getValue(String.class);

                            entries.add(first + " - " + second);
                        }

                        adapter.notifyDataSetChanged();

                        if (entries.isEmpty()) {
                            Toast.makeText(MainActivity.this,
                                    "No records found",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        Toast.makeText(MainActivity.this,
                                "Loading failed: " + error.getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                }
        );
    }
}
